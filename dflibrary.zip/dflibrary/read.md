### 怎么用
* 1 依赖aar库
       并引用以下库文件
       ```
           implementation 'com.just.agentweb:agentweb:4.0.2'
           implementation 'com.just.agentweb:download:4.0.2'
           implementation 'com.just.agentweb:filechooser:4.0.2'
           implementation 'com.lzy.net:okgo:2.1.4'
           implementation 'cn.jiguang.sdk:jpush:3.1.3'
           implementation 'cn.jiguang.sdk:jcore:1.2.1'
           implementation 'com.google.code.gson:gson:2.8.5'
       ```
* 2 清单文件配置极光
```
  manifestPlaceholders = [
                JPUSH_PKGNAME: applicationId,
                JPUSH_APPKEY : "3203ac8db7a18e861cab48bc", //JPush上注册的包名对应的appkey.
                JPUSH_CHANNEL: "developer-default", //暂时填写默认值即可.
        ]
```
* 3 自定义application，并继承DfApp
```
public class CrashApplication extends DfApp {
 @Override
    protected int setSplashRes() {//返回欢迎页图片
        return R.drawable.ssss;
    }

    @Override
    protected String setAppId() {//返回id
        return "newxk2018071410000";
    }

    @Override
    protected String setApplicationIId() {//返回应用id
        return BuildConfig.APPLICATION_ID;
    }

}
```
* 4 实现以上三个方法，返回相应信息
* 5 清单文件配置 设置启动页为SplashActivity
```
 <activity
            android:name="com.home.dflibrary.SplashActivity"
            android:label="@string/app_name"
            android:screenOrientation="portrait">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
```

